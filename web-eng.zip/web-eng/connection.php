<?php

$databaseHost = 'localhost';
$databaseName = 'web-engineering';
$databaseUsername = 'root';
$databasePassword = '';
$mysqli = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName);